import sys, types, torch, torch.nn as nn, torch.nn.functional as F
# Stub the repository's Transformer wrappers for isolated logic tests.
tools_deit = types.ModuleType('tools.deit_features')
tools_cait = types.ModuleType('tools.cait_features')
class MyVisionDummy(nn.Module):
    def __init__(self, pretrained=True):
        super().__init__()
        self.patch_embed = types.SimpleNamespace(num_patches=4)
        self.patch_proj = nn.Linear(3, 8)
        self.cls_proj = nn.Linear(3, 8)
        self.encoder = nn.Linear(8, 8)
    def forward_feature_patch_embed_all(self, x):
        x = F.adaptive_avg_pool2d(x, (2,2)).flatten(2).transpose(1,2)
        cls = self.cls_proj(x.mean(dim=1, keepdim=True))
        return cls, self.patch_proj(x)
    def forward_feature_mask_train_direct(self, cls, x, token_attn, reserve_layer_nums):
        all_tokens = self.encoder(torch.cat([cls, x], dim=1))
        attn = torch.ones(x.shape[0], x.shape[1], device=x.device) / x.shape[1]
        return all_tokens, (attn, None)
def make(pretrained=True): return MyVisionDummy(pretrained)
tools_deit.deit_tiny_patch_features = make
tools_deit.deit_small_patch_features = make
tools_cait.cait_xxs24_224_features = make
sys.modules['tools.deit_features'] = tools_deit
sys.modules['tools.cait_features'] = tools_cait
sys.path.insert(0, '/mnt/data/protopformer_qat_integer')
import protopformer
from tools.qat_utils import calibrate_observers

# Observer calibration can collect missing ranges in eval mode while preserving
# already calibrated ranges unchanged.
missing_observer = protopformer.QuantAct(8, signed=True)
missing_observer.eval()
missing_observer.calibration_mode = True
missing_observer(torch.tensor([[-2.0, 1.0]]))
assert missing_observer.running_max.item() == 2.0
fixed_observer = protopformer.QuantAct(8, signed=True)
fixed_observer.running_max.fill_(3.0)
fixed_observer.eval()
fixed_observer.calibration_mode = True
fixed_observer.observe = False
fixed_observer(torch.tensor([[1.0, 2.0]]))
assert fixed_observer.running_max.item() == 3.0
print('PASS eval-mode observer calibration and calibrated-range preservation')

class CalibrationToy(nn.Module):
    def __init__(self, include_zero_observer=False):
        super().__init__()
        self.missing = protopformer.QuantAct(8, signed=True)
        self.missing.running_max.fill_(float('nan'))
        self.fixed = protopformer.QuantAct(8, signed=True)
        self.fixed.running_max.fill_(5.0)
        self.unused = protopformer.QuantAct(8, signed=True)
        if include_zero_observer:
            self.zero = protopformer.QuantAct(8, signed=True)
        self.missing.observe = False
        self.missing.calibration_mode = False
    def forward(self, x):
        self.missing(x)
        self.fixed(x)
        if hasattr(self, 'zero'):
            self.zero(torch.zeros_like(x))
        return x

calibration_toy = CalibrationToy().train()
calibration_loader = [
    (torch.tensor([[2.0, -1.0]]), torch.tensor([0])),
    (torch.tensor([[9.0, -3.0]]), torch.tensor([0])),
]
calibrated_batches = calibrate_observers(
    calibration_toy, calibration_loader, torch.device('cpu'), protopformer.QuantAct)
assert calibrated_batches == 2
assert calibration_toy.missing.running_max.item() == 9.0
assert calibration_toy.fixed.running_max.item() == 5.0
assert calibration_toy.unused.running_max.item() == 0.0
assert calibration_toy.missing.observe is False and not calibration_toy.missing.calibration_mode
assert calibration_toy.training is False
try:
    calibrate_observers(CalibrationToy(include_zero_observer=True), calibration_loader,
                        torch.device('cpu'), protopformer.QuantAct)
except RuntimeError as error:
    assert 'zero' in str(error)
else:
    raise AssertionError('Expected calibration to reject a visited observer with no usable range.')
print('PASS observer helper: missing-only max calibration, flag restoration, and invalid-range detection')
for invalid_range in (float('nan'), float('inf'), float('-inf')):
    invalid_observer = protopformer.QuantAct(8, signed=True)
    invalid_observer.running_max.fill_(invalid_range)
    try:
        protopformer._observer_scale(invalid_observer, require_calibrated=False)
    except RuntimeError:
        pass
    else:
        raise AssertionError(f'Expected export to reject non-finite observer range {invalid_range}.')
print('PASS export rejects NaN and infinite observer ranges')

def run(use_global):
    model = protopformer.construct_PPNet('deit_tiny_patch16_224', pretrained=False,
        prototype_shape=(4,4,1,1), num_classes=2, reserve_layers=[1], reserve_token_nums=[4],
        use_global=use_global, global_proto_per_class=2, add_on_layers_type='regular',
        quantize=True, fmap_bits=8, weight_bits=8, act_bits=8, quantize_backbone=True)
    model.train()
    x=torch.rand(3,3,16,16)
    out, aux = model(x)
    assert out.shape == (3,2), out.shape
    loss=out.square().mean(); loss.backward()
    model.project_prototypes()
    # Eval reference path still returns finite values.
    model.eval()
    with torch.no_grad():
        ref,_=model(x)
    assert torch.isfinite(ref).all()
    # Conversion to integer-MAC CPU path and strict round-trip state load.
    deployed = __import__('copy').deepcopy(model).cpu().eval()
    deployed.convert_to_integer_deployment(require_calibrated=True)
    xd=x.cpu()
    with torch.no_grad():
        pred,_=deployed(xd)
    assert pred.shape == (3,2) and torch.isfinite(pred).all(), (pred.shape,pred)
    maxdiff=(ref.cpu()-pred).abs().max().item()
    print('max abs reference-vs-deploy difference:', maxdiff)
    state=deployed.state_dict()
    skeleton = protopformer.construct_PPNet('deit_tiny_patch16_224', pretrained=False,
        prototype_shape=(4,4,1,1), num_classes=2, reserve_layers=[1], reserve_token_nums=[4],
        use_global=use_global, global_proto_per_class=2, add_on_layers_type='regular',
        quantize=True, fmap_bits=8, weight_bits=8, act_bits=8, quantize_backbone=True)
    skeleton.cpu().convert_to_integer_deployment(require_calibrated=False)
    result=skeleton.load_state_dict(state, strict=True)
    with torch.no_grad():
        pred2,_=skeleton(xd)
    torch.testing.assert_close(pred, pred2)
    print('PASS', 'global' if use_global else 'local', 'qat', tuple(out.shape), 'integer', tuple(pred.shape), 'state keys',len(state))

run(False)
run(True)
# Check code-aware exact prototype distance against brute-force integer sum.
model = protopformer.construct_PPNet('deit_tiny_patch16_224', pretrained=False,
    prototype_shape=(4,4,1,1), num_classes=2, reserve_layers=[1], reserve_token_nums=[4],
    use_global=False, add_on_layers_type='regular', quantize=True)
model.cpu().convert_to_integer_deployment(require_calibrated=False)
qx=torch.randint(0,256,(2,4,2,2),dtype=torch.uint8)
qp=torch.randint(0,256,(3,4,1,1),dtype=torch.uint8)
d=model._quant_l2_distance(qx,qp)
ref=torch.empty_like(d)
for b in range(2):
  for p in range(3):
    for h in range(2):
      for w in range(2):
        ref[b,p,h,w]=((qx[b,:,h,w].to(torch.int64)-qp[p,:,0,0].to(torch.int64))**2).sum().item()*(model.fmap_scale**2)
torch.testing.assert_close(d,ref,rtol=0,atol=2e-7)
print('PASS exact integer prototype distance')
