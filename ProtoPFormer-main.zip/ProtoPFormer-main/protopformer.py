"""ProtoPFormer with custom 8-bit QAT and a CPU integer-MAC deployment path.

Training mode uses fake quantization (float tensors + STE).  The deployment
conversion replaces QLinear/QConv2d with modules whose dot products are carried
out on integer codes with int32 accumulators.  Integer prototype distances are
also accumulated with integer matrix multiplication.  Transformer operations
such as LayerNorm, softmax, GELU/sigmoid, residual additions, and the prototype
similarity mapping remain floating point; this is intentionally a hybrid
integer deployment, not an all-operators-integer ViT.
"""
from __future__ import annotations

import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from tools.deit_features import deit_tiny_patch_features, deit_small_patch_features
from tools.cait_features import cait_xxs24_224_features


# ---------------------------- Fake quantization ----------------------------
def _round_ste(x: torch.Tensor) -> torch.Tensor:
    """Round in forward; straight-through identity gradient in backward."""
    return x + (torch.round(x) - x).detach()


def fake_quantize(x: torch.Tensor, scale: torch.Tensor | float,
                  qmin: int, qmax: int) -> torch.Tensor:
    scale_t = torch.as_tensor(scale, dtype=x.dtype, device=x.device).clamp_min(1e-8)
    return torch.clamp(_round_ste(x / scale_t), qmin, qmax) * scale_t


class QuantAct(nn.Module):
    """Per-tensor activation fake quantizer with an EMA max observer."""
    def __init__(self, num_bits: int = 8, signed: bool = True, momentum: float = 0.99):
        super().__init__()
        if not 2 <= int(num_bits) <= 8:
            raise ValueError("QuantAct supports 2-8 bits; integer deployment currently supports 8 bits.")
        self.num_bits = int(num_bits)
        self.signed = bool(signed)
        self.momentum = float(momentum)
        self.observe = True
        self.calibration_mode = False
        self.num_calls = 0  # diagnostic only; not part of the checkpoint state
        self.qmax = 2 ** (self.num_bits - 1) - 1 if self.signed else 2 ** self.num_bits - 1
        self.qmin = -self.qmax if self.signed else 0
        self.register_buffer("running_max", torch.zeros(1, dtype=torch.float32))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        self.num_calls += 1
        orig_dtype = x.dtype
        xf = x.float()
        if (self.training or self.calibration_mode) and self.observe:
            with torch.no_grad():
                observed = xf.detach().abs().max() if self.signed else xf.detach().clamp_min(0).max()
                observed = observed.reshape(1)
                if self.calibration_mode:
                    self.running_max.copy_(torch.maximum(self.running_max, observed))
                elif self.running_max.item() <= 0:
                    self.running_max.copy_(observed)
                else:
                    self.running_max.mul_(self.momentum).add_(observed, alpha=1.0 - self.momentum)
        scale = (self.running_max / self.qmax).clamp_min(1e-8)
        if not self.training and not self.calibration_mode:
            observed_range = float(self.running_max.detach().item())
            if not math.isfinite(observed_range) or observed_range <= 0:
                raise RuntimeError("Invalid QuantAct range: run QAT or observer calibration before eval/export.")
        return fake_quantize(xf, scale, self.qmin, self.qmax).to(orig_dtype)


class _QWeightMixin:
    """Per-output-channel symmetric fake quantization for weights."""
    weight_bits: int
    weight: torch.Tensor

    def _weight_qmax(self) -> int:
        return 2 ** (int(self.weight_bits) - 1) - 1

    def _weight_scale(self) -> torch.Tensor:
        qmax = self._weight_qmax()
        dims = tuple(range(1, self.weight.dim()))
        return self.weight.detach().float().abs().amax(dim=dims, keepdim=True).clamp_min(1e-8) / qmax

    def quant_weight(self) -> torch.Tensor:
        qmax = self._weight_qmax()
        return fake_quantize(self.weight, self._weight_scale(), -qmax, qmax)

    def int_weight(self):
        qmax = self._weight_qmax()
        scale = self._weight_scale()
        q = torch.round(self.weight.detach().float() / scale).clamp(-qmax, qmax).to(torch.int8)
        return q, scale.reshape(-1)


class QConv2d(_QWeightMixin, nn.Conv2d):
    """QAT Conv2d used by ProtoPFormer; deployment currently supports its 1x1 form."""
    def __init__(self, *args, weight_bits=8, act_bits=8, signed_input=True, **kwargs):
        super().__init__(*args, **kwargs)
        self.weight_bits = int(weight_bits)
        self.in_quant = QuantAct(act_bits, signed=signed_input)

    def forward(self, x):
        xq = self.in_quant(x)
        return F.conv2d(xq, self.quant_weight(), self.bias, self.stride,
                        self.padding, self.dilation, self.groups)


class QLinear(_QWeightMixin, nn.Linear):
    """QAT Linear with fake-quantized input/weights and float output."""
    def __init__(self, *args, weight_bits=8, act_bits=8, **kwargs):
        super().__init__(*args, **kwargs)
        self.weight_bits = int(weight_bits)
        self.in_quant = QuantAct(act_bits, signed=True)

    def forward(self, x):
        return F.linear(self.in_quant(x), self.quant_weight(), self.bias)


def quantize_linear_layers(module: nn.Module, weight_bits=8, act_bits=8):
    """Replace every nn.Linear below module with QLinear, sharing pretrained Parameters."""
    for name, child in list(module.named_children()):
        if isinstance(child, QLinear):
            continue
        if type(child) is nn.Linear:
            q = QLinear(child.in_features, child.out_features, bias=child.bias is not None,
                        weight_bits=weight_bits, act_bits=act_bits,
                        device=child.weight.device, dtype=child.weight.dtype)
            q.weight = child.weight
            q.bias = child.bias
            q.train(child.training)
            setattr(module, name, q)
        else:
            quantize_linear_layers(child, weight_bits, act_bits)
    return module


class UnitRangeQuantizer(nn.Module):
    """Fixed [0,1] code grid for sigmoid-bounded feature maps and prototypes.

    QAT returns code-valued floats (for STE gradients); eval returns uint8 codes.
    The physical real value represented by a code is code / (2**bits - 1).
    """
    def __init__(self, num_bits=8):
        super().__init__()
        if int(num_bits) != 8:
            raise ValueError("The integer deployment path currently supports 8-bit [0,1] codes only.")
        self.num_bits = int(num_bits)
        self.levels = 2 ** self.num_bits - 1
        self.scale = 1.0 / self.levels

    @torch.no_grad()
    def to_int(self, x):
        return torch.round(x.detach().float().clamp(0., 1.) * self.levels).to(torch.uint8)

    def forward(self, x):
        if not self.training:
            return self.to_int(x)
        return _round_ste(x.float() * self.levels).clamp(0, self.levels)


# ------------------------- Integer deployment ops -------------------------
def _quantize_weight_per_output(weight: torch.Tensor):
    """Return int8 weights and a float32 scale per output channel."""
    wf = weight.detach().float()
    reduce_dims = tuple(range(1, wf.ndim))
    scales = wf.abs().amax(dim=reduce_dims).clamp_min(1e-8) / 127.0
    reshape = (scales.shape[0],) + (1,) * (wf.ndim - 1)
    codes = torch.round(wf / scales.reshape(reshape)).clamp(-127, 127).to(torch.int8)
    return codes, scales


def _observer_scale(observer: QuantAct, require_calibrated: bool) -> float:
    value = float(observer.running_max.detach().cpu().item())
    if not math.isfinite(value):
        raise RuntimeError("Cannot export integer deployment: activation observer range is NaN or infinite.")
    if value <= 0:
        if require_calibrated:
            raise RuntimeError("Cannot export integer deployment: an activation observer has no range. "
                               "Train/calibrate first, or inspect which layer was unused.")
        # Used only to construct a loadable deployment skeleton; exported checkpoint
        # immediately overwrites this placeholder with its calibrated value.
        value = 1.0
    return max(value / observer.qmax, 1e-8)


class IntegerLinear(nn.Module):
    """Linear layer using int8 codes and int32 matrix-multiply accumulation on CPU.

    Output is dequantized to float32 so unsupported surrounding Transformer ops can
    remain floating point. This module is inference-only.
    """
    def __init__(self, in_features: int, out_features: int, bias: bool,
                 input_scale: float = 1.0, input_signed: bool = True,
                 dynamic_input: bool = False):
        super().__init__()
        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.input_signed = bool(input_signed)
        # Persistent buffer: export/load must preserve whether the observer was
        # calibrated (fixed QAT scale) or the layer was unused (dynamic fallback).
        self.register_buffer("dynamic_input", torch.tensor(bool(dynamic_input), dtype=torch.bool))
        self.register_buffer("weight_int", torch.zeros(out_features, in_features, dtype=torch.int8))
        self.register_buffer("weight_scale", torch.ones(out_features, dtype=torch.float32))
        self.register_buffer("input_scale", torch.tensor(float(input_scale), dtype=torch.float32))
        self.register_buffer("bias_int", torch.zeros(out_features, dtype=torch.int32))
        if bias:
            self.register_buffer("bias_fp", torch.zeros(out_features, dtype=torch.float32))
        else:
            self.register_buffer("bias_fp", None)

    @classmethod
    def from_qlinear(cls, source: QLinear, require_calibrated: bool):
        observer_range = float(source.in_quant.running_max.detach().cpu().item())
        if not math.isfinite(observer_range):
            raise RuntimeError("Cannot export integer deployment: activation observer range is NaN or infinite.")
        has_observer_range = observer_range > 0
        if not has_observer_range and source.in_quant.num_calls == 0:
            # Some wrappers contain classifier/head linears that are never used by
            # forward_feature_*(). Preserve such unused layers with runtime input
            # quantization instead of failing export on an observer that never ran.
            scale_in = 1.0
            dynamic_input = True
        else:
            scale_in = _observer_scale(source.in_quant, require_calibrated)
            dynamic_input = False
        out = cls(source.in_features, source.out_features, source.bias is not None,
                  input_scale=scale_in, input_signed=True, dynamic_input=dynamic_input)
        qw, sw = _quantize_weight_per_output(source.weight)
        out.weight_int.copy_(qw.reshape(source.out_features, source.in_features).cpu())
        out.weight_scale.copy_(sw.cpu())
        if source.bias is not None:
            out.bias_fp.copy_(source.bias.detach().float().cpu())
            bq = torch.round(out.bias_fp / (out.input_scale * out.weight_scale)).to(torch.int32)
            out.bias_int.copy_(bq)
        return out

    @classmethod
    def from_float(cls, source: nn.Linear):
        """Quantize ordinary (non-QAT-observed) linear weights; scale input per call."""
        out = cls(source.in_features, source.out_features, source.bias is not None,
                  input_scale=1.0, input_signed=True, dynamic_input=True)
        qw, sw = _quantize_weight_per_output(source.weight)
        out.weight_int.copy_(qw.reshape(source.out_features, source.in_features).cpu())
        out.weight_scale.copy_(sw.cpu())
        if source.bias is not None:
            out.bias_fp.copy_(source.bias.detach().float().cpu())
        return out

    def forward(self, x):
        if x.device.type != "cpu":
            raise RuntimeError("IntegerLinear deployment kernels in this implementation require CPU tensors.")
        xf = x.float()
        original_shape = xf.shape[:-1]
        flat = xf.reshape(-1, self.in_features)
        if self.dynamic_input:
            scale_in = (flat.detach().abs().amax() / 127.0).clamp_min(1e-8)
        else:
            scale_in = self.input_scale.clamp_min(1e-8)
        qx = torch.round(flat / scale_in).clamp(-127, 127).to(torch.int32)
        acc = torch.matmul(qx, self.weight_int.to(torch.int32).t())
        if self.bias_fp is not None:
            if self.dynamic_input:
                bias_codes = torch.round(self.bias_fp / (scale_in * self.weight_scale)).to(torch.int32)
            else:
                bias_codes = self.bias_int
            acc = acc + bias_codes
        out = acc.float() * scale_in * self.weight_scale.reshape(1, -1)
        return out.reshape(*original_shape, self.out_features)


class IntegerConv1x1(nn.Module):
    """Integer-MAC equivalent of the 1x1 Conv2d layers used in PPNet add-on blocks."""
    def __init__(self, in_channels: int, out_channels: int, bias: bool,
                 input_scale: float = 1.0, input_signed: bool = True):
        super().__init__()
        self.in_channels = int(in_channels)
        self.out_channels = int(out_channels)
        self.input_signed = bool(input_signed)
        self.register_buffer("weight_int", torch.zeros(out_channels, in_channels, 1, 1, dtype=torch.int8))
        self.register_buffer("weight_scale", torch.ones(out_channels, dtype=torch.float32))
        self.register_buffer("input_scale", torch.tensor(float(input_scale), dtype=torch.float32))
        self.register_buffer("bias_int", torch.zeros(out_channels, dtype=torch.int32))
        if bias:
            self.register_buffer("bias_fp", torch.zeros(out_channels, dtype=torch.float32))
        else:
            self.register_buffer("bias_fp", None)

    @classmethod
    def from_qconv(cls, source: QConv2d, require_calibrated: bool):
        if tuple(source.kernel_size) != (1, 1) or tuple(source.stride) != (1, 1) or \
           tuple(source.padding) != (0, 0) or tuple(source.dilation) != (1, 1) or source.groups != 1:
            raise ValueError("Integer deployment currently supports only groups=1, 1x1, stride=1, padding=0 Conv2d.")
        scale_in = _observer_scale(source.in_quant, require_calibrated)
        out = cls(source.in_channels, source.out_channels, source.bias is not None,
                  input_scale=scale_in, input_signed=source.in_quant.signed)
        qw, sw = _quantize_weight_per_output(source.weight)
        out.weight_int.copy_(qw.reshape_as(out.weight_int).cpu())
        out.weight_scale.copy_(sw.cpu())
        if source.bias is not None:
            out.bias_fp.copy_(source.bias.detach().float().cpu())
            out.bias_int.copy_(torch.round(out.bias_fp / (out.input_scale * out.weight_scale)).to(torch.int32))
        return out

    def forward(self, x):
        if x.device.type != "cpu":
            raise RuntimeError("IntegerConv1x1 deployment kernels in this implementation require CPU tensors.")
        xf = x.float()
        b, c, h, w = xf.shape
        qmin = -127 if self.input_signed else 0
        qmax = 127 if self.input_signed else 255
        qx = torch.round(xf / self.input_scale.clamp_min(1e-8)).clamp(qmin, qmax)
        qx = qx.permute(0, 2, 3, 1).reshape(b, h * w, c).to(torch.int32)
        qw = self.weight_int[:, :, 0, 0].to(torch.int32)
        acc = torch.matmul(qx, qw.t())
        if self.bias_fp is not None:
            acc = acc + self.bias_int.reshape(1, 1, -1)
        out = acc.float() * self.input_scale * self.weight_scale.reshape(1, 1, -1)
        return out.reshape(b, h, w, self.out_channels).permute(0, 3, 1, 2).contiguous()


base_architecture_to_features = {
    "deit_tiny_patch16_224": deit_tiny_patch_features,
    "deit_small_patch16_224": deit_small_patch_features,
    "cait_xxs24_224": cait_xxs24_224_features,
}


class PPNet(nn.Module):
    def __init__(self, features, img_size, prototype_shape, proto_layer_rf_info, num_classes,
                 reserve_layers=None, reserve_token_nums=None, use_global=False, use_ppc_loss=False,
                 ppc_cov_thresh=2., ppc_mean_thresh=2, global_coe=0.3,
                 global_proto_per_class=10, init_weights=True,
                 prototype_activation_function="log", add_on_layers_type="bottleneck",
                 quantize=False, fmap_bits=8, weight_bits=8, act_bits=8,
                 quantize_backbone=True):
        super().__init__()
        self.quantize = bool(quantize)
        self.fmap_bits = int(fmap_bits)
        self.weight_bits = int(weight_bits)
        self.act_bits = int(act_bits)
        self.quantize_backbone = bool(quantize_backbone)
        self.integer_deployment = False
        if self.quantize:
            if self.fmap_bits != 8 or self.weight_bits != 8 or self.act_bits != 8:
                raise ValueError("This end-to-end integer deployment path is implemented for 8-bit QAT only.")
            self.unit_quant = UnitRangeQuantizer(self.fmap_bits)
            self.fmap_scale = self.unit_quant.scale
        else:
            self.unit_quant = None
            self.fmap_scale = 1.0

        self.img_size = img_size
        self.prototype_shape = list(prototype_shape)
        self.num_prototypes = int(prototype_shape[0])
        self.num_classes = int(num_classes)
        self.reserve_layers = list(reserve_layers or [])
        self.reserve_token_nums = list(reserve_token_nums or [])
        if len(self.reserve_layers) != len(self.reserve_token_nums):
            raise ValueError("reserve_layers and reserve_token_nums must have the same length.")
        if self.reserve_token_nums and any(n <= 0 for n in self.reserve_token_nums):
            raise ValueError("All reserve_token_nums must be positive.")
        if self.reserve_token_nums and any(a > b for a, b in zip(self.reserve_token_nums, self.reserve_token_nums[1:])):
            raise ValueError("reserve_token_nums must be non-decreasing by layer.")
        if self.reserve_token_nums and self.reserve_token_nums[-1] ** 0.5 % 1 != 0:
            raise ValueError("The final reserve_token_nums value must be a square number for a 2-D feature map.")
        self.use_global = bool(use_global)
        self.use_ppc_loss = bool(use_ppc_loss)
        self.ppc_cov_thresh = float(ppc_cov_thresh)
        self.ppc_mean_thresh = float(ppc_mean_thresh)
        self.global_coe = float(global_coe)
        self.global_proto_per_class = int(global_proto_per_class)
        self.epsilon = 1e-4
        self.reserve_layer_nums = list(zip(self.reserve_layers, self.reserve_token_nums))
        self.num_prototypes_global = self.num_classes * self.global_proto_per_class
        self.prototype_shape_global = [self.num_prototypes_global] + self.prototype_shape[1:]
        self.prototype_activation_function = prototype_activation_function

        if self.num_classes <= 0 or self.num_prototypes % self.num_classes != 0:
            raise ValueError("prototype_shape[0] must be divisible by num_classes.")
        self.num_prototypes_per_class = self.num_prototypes // self.num_classes
        self.prototype_class_identity = torch.zeros(self.num_prototypes, self.num_classes)
        self.prototype_class_identity_global = torch.zeros(self.num_prototypes_global, self.num_classes)
        for j in range(self.num_prototypes):
            self.prototype_class_identity[j, j // self.num_prototypes_per_class] = 1
        num_global_per_class = self.num_prototypes_global // self.num_classes
        for j in range(self.num_prototypes_global):
            self.prototype_class_identity_global[j, j // num_global_per_class] = 1

        self.proto_layer_rf_info = proto_layer_rf_info
        self.features = features
        features_name = self.features.__class__.__name__.upper()
        if not (features_name.startswith("MYVISION") or features_name.startswith("MYCAIT")):
            raise ValueError("Unsupported feature wrapper: expected MyVision* or MyCait*.")
        linear_modules = [m for m in self.features.modules() if isinstance(m, nn.Linear)]
        if not linear_modules:
            raise ValueError("Could not infer Transformer feature dimension: no nn.Linear module found.")
        first_add_on_layer_in_channels = linear_modules[-1].out_features
        self.num_patches = self.features.patch_embed.num_patches

        if self.quantize and self.quantize_backbone:
            quantize_linear_layers(self.features, weight_bits=self.weight_bits, act_bits=self.act_bits)

        def make_conv(in_c, out_c, signed_input):
            if self.quantize:
                return QConv2d(in_channels=in_c, out_channels=out_c, kernel_size=1,
                               weight_bits=self.weight_bits, act_bits=self.act_bits,
                               signed_input=signed_input)
            return nn.Conv2d(in_channels=in_c, out_channels=out_c, kernel_size=1)

        if add_on_layers_type == "bottleneck":
            layers = []
            current_in = first_add_on_layer_in_channels
            while current_in > self.prototype_shape[1] or not layers:
                current_out = max(self.prototype_shape[1], current_in // 2)
                layers.append(make_conv(current_in, current_out, signed_input=(len(layers) == 0)))
                layers.append(nn.ReLU())
                layers.append(make_conv(current_out, current_out, signed_input=False))
                if current_out > self.prototype_shape[1]:
                    layers.append(nn.ReLU())
                else:
                    if current_out != self.prototype_shape[1]:
                        raise RuntimeError("Invalid add-on bottleneck channel progression.")
                    layers.append(nn.Sigmoid())
                current_in = current_in // 2
            self.add_on_layers = nn.Sequential(*layers)
        elif add_on_layers_type == "regular":
            self.add_on_layers = nn.Sequential(
                make_conv(first_add_on_layer_in_channels, self.prototype_shape[1], signed_input=True),
                nn.Sigmoid(),
            )
        else:
            raise ValueError("add_on_layers_type must be 'regular' or 'bottleneck'.")

        self.prototype_vectors = nn.Parameter(torch.rand(self.prototype_shape), requires_grad=True)
        if self.use_global:
            self.prototype_vectors_global = nn.Parameter(torch.rand(self.prototype_shape_global), requires_grad=True)
        # Legacy buffer, no longer used in the distance implementation.
        self.ones = nn.Parameter(torch.ones(self.prototype_shape), requires_grad=False)
        self.last_layer = nn.Linear(self.num_prototypes, self.num_classes, bias=False)
        self.last_layer_global = nn.Linear(self.num_prototypes_global, self.num_classes, bias=False)
        self.last_layer.weight.requires_grad_(False)
        self.last_layer_global.weight.requires_grad_(False)
        self.all_attn_mask = None
        self.teacher_model = None
        self.scale = self.prototype_shape[1] ** -0.5
        if init_weights:
            self._initialize_weights()

    def conv_features(self, x, reserve_layer_nums=None):
        """Extract CLS and reserved image-token feature maps before prototypes."""
        reserve_layer_nums = self.reserve_layer_nums if reserve_layer_nums is None else reserve_layer_nums
        feature_name = self.features.__class__.__name__
        if "Vision" not in feature_name and "MyCait" not in feature_name:
            raise RuntimeError("The ProtoPFormer feature extraction path supports the configured ViT/CaiT wrappers only.")
        if not reserve_layer_nums:
            raise ValueError("reserve_layers/reserve_token_nums must be set for ProtoPFormer token selection.")
        if not hasattr(self.features, "forward_feature_patch_embed_all"):
            raise RuntimeError("Feature wrapper must implement forward_feature_patch_embed_all().")
        cls_embed, x_embed = self.features.forward_feature_patch_embed_all(x)
        token_attn = None
        x_out, (cls_token_attn, _) = self.features.forward_feature_mask_train_direct(
            cls_embed, x_embed, token_attn, reserve_layer_nums
        )
        final_reserve_num = int(reserve_layer_nums[-1][1])
        final_reserve_indices = torch.topk(cls_token_attn, k=final_reserve_num, dim=-1).indices
        final_reserve_indices = final_reserve_indices.sort(dim=-1).values
        dim = x_out.shape[-1]
        final_reserve_indices = final_reserve_indices.unsqueeze(-1).expand(-1, -1, dim)
        cls_tokens, img_tokens = x_out[:, :1], x_out[:, 1:]
        img_tokens = torch.gather(img_tokens, 1, final_reserve_indices)
        b, token_count, dim = img_tokens.shape[0], img_tokens.shape[1], img_tokens.shape[2]
        side = int(math.sqrt(token_count))
        if side * side != token_count:
            raise ValueError(f"Reserved token count {token_count} must form a square 2-D grid.")
        cls_tokens = cls_tokens.permute(0, 2, 1).reshape(b, dim, 1, 1)
        img_tokens = img_tokens.permute(0, 2, 1).reshape(b, dim, side, side)
        cls_tokens = self.add_on_layers(cls_tokens)
        img_tokens = self.add_on_layers(img_tokens)
        if self.quantize:
            cls_tokens = self.unit_quant(cls_tokens)
            img_tokens = self.unit_quant(img_tokens)
        return (cls_tokens, img_tokens), (token_attn, cls_token_attn, None)

    @staticmethod
    def _weighted_l2_convolution(input, filter, weights):
        input_patch_weighted_norm2 = F.conv2d(input=input ** 2, weight=weights)
        weighted_filter2 = (filter ** 2) * weights
        filter_norm = weighted_filter2.sum(dim=(1, 2, 3)).view(-1, 1, 1)
        weighted_inner_product = F.conv2d(input=input, weight=filter * weights)
        return F.relu(input_patch_weighted_norm2 - 2 * weighted_inner_product + filter_norm)

    def _quant_l2_distance(self, q_x, q_p):
        """Distance using quantized codes.

        In normal QAT/eval this is a floating reference simulation. In converted
        integer deployment, int32 matmul and int32 sums perform the distance MACs;
        only the final distance scaling is floating point.
        """
        if self.integer_deployment:
            if q_x.device.type != "cpu" or q_x.is_floating_point() or q_p.is_floating_point():
                raise RuntimeError("Integer prototype-distance inference requires integer codes on CPU.")
            b, c, h, w = q_x.shape
            x = q_x.permute(0, 2, 3, 1).reshape(b, h * w, c).to(torch.int32)
            p = q_p.reshape(q_p.shape[0], c).to(torch.int32)
            # Maximum sum for 8-bit codes and these prototype dimensions fits int32.
            dot = torch.matmul(x, p.t())
            x2 = (x * x).sum(dim=-1, keepdim=True, dtype=torch.int32)
            p2 = (p * p).sum(dim=-1, dtype=torch.int32).reshape(1, 1, -1)
            d_codes = (x2 + p2 - 2 * dot).clamp_min(0)
            return d_codes.reshape(b, h, w, -1).permute(0, 3, 1, 2).contiguous().float() * (self.fmap_scale ** 2)

        # Fake-quant/reference path: operations remain float so training can backpropagate.
        with torch.autocast(device_type=q_x.device.type, enabled=False):
            x = q_x.float()
            p = q_p.float()
            x2 = (x * x).sum(dim=1, keepdim=True)
            p2 = (p * p).sum(dim=(1, 2, 3)).view(-1, 1, 1)
            xp = F.conv2d(input=x, weight=p)
            d = F.relu(x2 - 2 * xp + p2) * (self.fmap_scale ** 2)
        return d.float()

    def _l2_convolution_single(self, x, prototype_vectors):
        ones = torch.ones_like(prototype_vectors)
        x2_patch_sum = F.conv2d(input=x ** 2, weight=ones)
        p2 = (prototype_vectors ** 2).sum(dim=(1, 2, 3)).view(-1, 1, 1)
        xp = F.conv2d(input=x, weight=prototype_vectors)
        return F.relu(x2_patch_sum - 2 * xp + p2)

    def prototype_distances(self, x, reserve_layer_nums=None):
        features, aux = self.conv_features(x, reserve_layer_nums)
        cls_tokens, img_tokens = features
        if self.use_global:
            return features, aux
        if self.quantize:
            p_codes = self.prototype_vectors if self.integer_deployment else self.unit_quant(self.prototype_vectors)
            distances = self._quant_l2_distance(img_tokens, p_codes)
        else:
            distances = self._l2_convolution_single(img_tokens, self.prototype_vectors)
        return distances, aux

    def distance_2_similarity(self, distances):
        if self.prototype_activation_function == "log":
            return torch.log((distances + 1) / (distances + self.epsilon))
        if self.prototype_activation_function == "linear":
            return -distances
        if callable(self.prototype_activation_function):
            return self.prototype_activation_function(distances)
        raise ValueError(f"Unsupported prototype activation function: {self.prototype_activation_function}")

    def get_activations(self, tokens, prototype_vectors):
        batch_size, num_prototypes = tokens.shape[0], prototype_vectors.shape[0]
        if self.quantize:
            p_codes = prototype_vectors if self.integer_deployment else self.unit_quant(prototype_vectors)
            distances = self._quant_l2_distance(tokens, p_codes)
        else:
            distances = self._l2_convolution_single(tokens, prototype_vectors)
        activations = self.distance_2_similarity(distances)
        total_proto_act = activations
        feature_size = activations.shape[-1]
        if feature_size > 1:
            activations = F.max_pool2d(activations, kernel_size=(feature_size, feature_size))
        activations = activations.reshape(batch_size, num_prototypes)
        if self.use_global:
            return activations, (distances, total_proto_act)
        return activations

    def batch_cov(self, points, weights):
        b, n, d = points.size()
        weights = weights / weights.sum(dim=-1, keepdim=True).clamp_min(1e-8) * n
        mean = (points * weights[:, :, None]).mean(dim=1).unsqueeze(1)
        diffs = (points - mean).reshape(b * n, d)
        prods = torch.bmm(diffs.unsqueeze(2), diffs.unsqueeze(1)).reshape(b, n, d, d)
        prods = prods * weights[:, :, None, None]
        cov = prods.sum(dim=1) / max(n - 1, 1)
        return mean, cov

    def get_PPC_loss(self, total_proto_act, cls_attn_rollout, original_fea_len, label):
        device = total_proto_act.device
        batch_size = total_proto_act.shape[0]
        original_fea_size = int(original_fea_len ** 0.5)
        proto_per_class = self.num_prototypes_per_class
        discrete_values = torch.tensor(
            [[x, y] for x in range(original_fea_size) for y in range(original_fea_size)],
            device=device, dtype=torch.float32,
        )[None, :, :].repeat(batch_size * proto_per_class, 1, 1)
        discrete_weights = torch.zeros(batch_size, proto_per_class, original_fea_len, device=device)
        total_proto_act = total_proto_act.flatten(start_dim=2)
        final_token_num = total_proto_act.shape[-1]
        proto_indices = (label * proto_per_class).unsqueeze(-1).repeat(1, proto_per_class)
        proto_indices += torch.arange(proto_per_class, device=label.device)
        proto_indices = proto_indices[:, :, None].expand(-1, -1, final_token_num)
        total_proto_act = torch.gather(total_proto_act, 1, proto_indices)
        reserve_token_indices = torch.topk(cls_attn_rollout, k=final_token_num, dim=-1).indices.sort(dim=-1).values
        reserve_token_indices = reserve_token_indices[:, None, :].expand(-1, proto_per_class, -1)
        discrete_weights.scatter_(2, reserve_token_indices, total_proto_act)
        discrete_weights = discrete_weights.reshape(batch_size * proto_per_class, -1)
        mean_ma, cov_ma = self.batch_cov(discrete_values, discrete_weights)
        cov_loss = F.relu((cov_ma[:, 0, 0] + cov_ma[:, 1, 1]) / 2 - self.ppc_cov_thresh).mean()
        mean_ma = mean_ma.reshape(batch_size, proto_per_class, 2)
        mean_diff = torch.cdist(mean_ma, mean_ma)
        mean_mask = 1. - torch.eye(proto_per_class, device=device)
        mean_loss = F.relu((self.ppc_mean_thresh - mean_diff) * mean_mask).mean()
        return cov_loss, mean_loss

    def forward(self, x):
        reserve_layer_nums = self.reserve_layer_nums
        if not self.training and self.use_global:
            (cls_tokens, img_tokens), (token_attn, cls_token_attn, _) = self.prototype_distances(x, reserve_layer_nums)
            global_acts, _ = self.get_activations(cls_tokens, self.prototype_vectors_global)
            local_acts, (distances, _) = self.get_activations(img_tokens, self.prototype_vectors)
            logits_global = self.last_layer_global(global_acts)
            logits_local = self.last_layer(local_acts)
            logits = self.global_coe * logits_global + (1. - self.global_coe) * logits_local
            return logits, (cls_token_attn, distances, logits_global, logits_local)

        if self.use_global:
            (cls_tokens, img_tokens), (student_token_attn, cls_attn_rollout, _) = self.prototype_distances(x, reserve_layer_nums)
            cls_attn_rollout = cls_attn_rollout.detach()
            global_acts, _ = self.get_activations(cls_tokens, self.prototype_vectors_global)
            local_acts, (_, total_proto_act) = self.get_activations(img_tokens, self.prototype_vectors)
            logits_global = self.last_layer_global(global_acts)
            logits_local = self.last_layer(local_acts)
            logits = self.global_coe * logits_global + (1. - self.global_coe) * logits_local
        else:
            distances, (student_token_attn, cls_attn_rollout, _) = self.prototype_distances(x, reserve_layer_nums)
            feature_size = distances.shape[-1]
            prototype_activations = self.distance_2_similarity(distances)
            total_proto_act = prototype_activations
            prototype_activations = F.max_pool2d(prototype_activations, kernel_size=(feature_size, feature_size))
            prototype_activations = prototype_activations.view(-1, self.num_prototypes)
            logits = self.last_layer(prototype_activations)

        attn_loss = torch.zeros(1, device=logits.device)
        original_fea_len = int(cls_attn_rollout.shape[-1])
        return logits, (student_token_attn, attn_loss, total_proto_act, cls_attn_rollout, original_fea_len)

    def push_forward(self, x):
        (cls_tokens, img_tokens), (_, cls_token_attn, _) = self.prototype_distances(x, self.reserve_layer_nums)
        global_acts, _ = self.get_activations(cls_tokens, self.prototype_vectors_global)
        local_acts, (distances, proto_acts) = self.get_activations(img_tokens, self.prototype_vectors)
        return cls_token_attn, proto_acts

    def set_quant_observer(self, enabled):
        for module in self.modules():
            if isinstance(module, QuantAct):
                module.observe = bool(enabled)

    @torch.no_grad()
    def project_prototypes(self):
        if not self.quantize or self.integer_deployment:
            return
        self.prototype_vectors.clamp_(0., 1.)
        if self.use_global:
            self.prototype_vectors_global.clamp_(0., 1.)

    @torch.no_grad()
    def convert_to_integer_deployment(self, require_calibrated=True):
        """Convert QAT modules and prototype tensors to an inference-only CPU model.

        Integer MACs are used in QLinear/QConv2d replacements and prototype-distance
        accumulation. LayerNorm, attention softmax, activations and similarity/logits
        composition remain float32. Call only after training and observer calibration.
        """
        if not self.quantize:
            raise RuntimeError("Build/train with quantize=True before integer deployment conversion.")
        if self.integer_deployment:
            return self
        if self.fmap_bits != 8 or self.weight_bits != 8 or self.act_bits != 8:
            raise ValueError("Only 8-bit deployment is implemented by this converter.")

        self.cpu()

        def convert_children(parent):
            for name, child in list(parent.named_children()):
                if isinstance(child, QLinear):
                    setattr(parent, name, IntegerLinear.from_qlinear(child, require_calibrated))
                elif isinstance(child, QConv2d):
                    setattr(parent, name, IntegerConv1x1.from_qconv(child, require_calibrated))
                else:
                    convert_children(child)

        convert_children(self.features)
        convert_children(self.add_on_layers)
        # If quantize_backbone=False, ordinary backbone linears were not QAT-prepared;
        # keep them float rather than implying that they were QAT trained.
        # These frozen classification heads were not prepared or calibrated during
        # QAT. Keep them in float so deployment does not introduce batch-dependent
        # activation scales that the training/evaluation path never saw.

        # Store prototypes as real uint8 code buffers (not float Parameters).
        p = self.unit_quant.to_int(self.prototype_vectors).cpu()
        del self._parameters["prototype_vectors"]
        self.register_buffer("prototype_vectors", p)
        if self.use_global:
            pg = self.unit_quant.to_int(self.prototype_vectors_global).cpu()
            del self._parameters["prototype_vectors_global"]
            self.register_buffer("prototype_vectors_global", pg)
        if "ones" in self._parameters:
            del self._parameters["ones"]
        self.integer_deployment = True
        self.eval()
        return self

    def __repr__(self):
        return (f"PPNet(features={self.features}, img_size={self.img_size}, "
                f"prototype_shape={self.prototype_shape}, num_classes={self.num_classes}, "
                f"quantize={self.quantize}, integer_deployment={self.integer_deployment})")

    def set_last_layer_incorrect_connection(self, incorrect_strength):
        positive = self.prototype_class_identity.t()
        negative = 1 - positive
        with torch.no_grad():
            self.last_layer.weight.copy_(positive + incorrect_strength * negative)
            if hasattr(self, "last_layer_global"):
                positive_g = self.prototype_class_identity_global.t()
                negative_g = 1 - positive_g
                self.last_layer_global.weight.copy_(positive_g + incorrect_strength * negative_g)

    def _initialize_weights(self):
        for module in self.add_on_layers.modules():
            if isinstance(module, (nn.Conv2d, QConv2d)):
                nn.init.kaiming_normal_(module.weight, mode="fan_out", nonlinearity="relu")
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
        self.set_last_layer_incorrect_connection(incorrect_strength=-0.5)


class BaseNet(nn.Module):
    """Legacy baseline network retained for compatibility with existing scripts."""
    def __init__(self, base_architecture, pretrained=True, img_size=224, num_classes=200, init_weights=True):
        super().__init__()
        self.base_architecture = base_architecture
        self.features = base_architecture_to_features[base_architecture](pretrained=pretrained)
        self.img_size = img_size
        self.num_classes = num_classes
        linear_modules = [m for m in self.features.modules() if isinstance(m, nn.Linear)]
        if not linear_modules:
            raise ValueError("No linear layer available to infer feature dimension.")
        self.last_layer = nn.Linear(linear_modules[-1].out_features, num_classes, bias=True)
        if init_weights:
            nn.init.kaiming_normal_(self.last_layer.weight, 1)
            nn.init.constant_(self.last_layer.bias, 0)

    def forward(self, x):
        if "deit" in self.base_architecture:
            x = self.features.forward_features(x)
        else:
            x = self.features(x)
            x = F.adaptive_avg_pool2d(x, 1).flatten(1)
        return self.last_layer(x), None

    def push_forward(self, x):
        conv_features = self.features.forward_feature_maps(x)
        b, token_count, dim = conv_features.shape
        side = int(math.sqrt(token_count))
        return conv_features.permute(0, 2, 1).reshape(b, dim, side, side)


def construct_PPNet(base_architecture, pretrained=True, img_size=224,
                    prototype_shape=(2000, 512, 1, 1), num_classes=200,
                    reserve_layers=None, reserve_token_nums=None, use_global=False,
                    use_ppc_loss=False, ppc_cov_thresh=1., ppc_mean_thresh=2.,
                    global_coe=0.5, global_proto_per_class=10,
                    prototype_activation_function="log", add_on_layers_type="bottleneck",
                    quantize=False, fmap_bits=8, weight_bits=8, act_bits=8,
                    quantize_backbone=True):
    if base_architecture not in base_architecture_to_features:
        raise ValueError(f"Unsupported base architecture: {base_architecture}")
    features = base_architecture_to_features[base_architecture](pretrained=pretrained)
    proto_layer_rf_info = [14, 16, 16, 8.0]
    return PPNet(
        features=features, img_size=img_size, prototype_shape=prototype_shape,
        proto_layer_rf_info=proto_layer_rf_info, num_classes=num_classes,
        reserve_layers=reserve_layers, reserve_token_nums=reserve_token_nums,
        use_global=use_global, use_ppc_loss=use_ppc_loss,
        ppc_cov_thresh=ppc_cov_thresh, ppc_mean_thresh=ppc_mean_thresh,
        global_coe=global_coe, global_proto_per_class=global_proto_per_class,
        init_weights=True, prototype_activation_function=prototype_activation_function,
        add_on_layers_type=add_on_layers_type, quantize=quantize,
        fmap_bits=fmap_bits, weight_bits=weight_bits, act_bits=act_bits,
        quantize_backbone=quantize_backbone,
    )
