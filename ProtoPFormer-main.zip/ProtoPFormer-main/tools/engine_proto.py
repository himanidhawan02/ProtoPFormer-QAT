# Copyright (c) 2015-present, Facebook, Inc.
# All rights reserved.
"""Train/evaluation functions for ProtoPFormer, including QAT-safe handling."""
import math
import sys
import logging
from typing import Iterable, Optional

import torch
from timm.data import Mixup
from timm.utils import accuracy, ModelEma
from torch.nn.modules.loss import _Loss
from torch.utils.tensorboard import SummaryWriter
import tools.utils as utils


def _autocast_context(device: torch.device):
    """Use CUDA autocast only on CUDA; integer deployment is CPU-only."""
    return torch.autocast(device_type=device.type, enabled=(device.type == "cuda"))


def train_one_epoch(model: torch.nn.Module, criterion: _Loss,
                    data_loader: Iterable, optimizer: torch.optim.Optimizer,
                    tb_writer: SummaryWriter, iteration: int,
                    device: torch.device, epoch: int, loss_scaler,
                    max_norm: float = 0, model_ema: Optional[ModelEma] = None,
                    mixup_fn: Optional[Mixup] = None, args=None,
                    set_training_mode=True):
    model.train(set_training_mode)
    metric_logger = utils.MetricLogger(delimiter="  ")
    metric_logger.add_meter("lr", utils.SmoothedValue(window_size=1, fmt="{value:.6f}"))
    header = f"Epoch: [{epoch}]"
    logger = logging.getLogger("train")
    logger.info("Start train one epoch")
    it = 0

    qat_model = model.module if hasattr(model, "module") else model
    use_qat = bool(getattr(qat_model, "quantize", False)) and not bool(
        getattr(qat_model, "integer_deployment", False)
    )

    for samples, targets in metric_logger.log_every(data_loader, 30, header):
        samples = samples.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)
        if mixup_fn is not None:
            samples, targets = mixup_fn(samples, targets)

        with _autocast_context(device):
            outputs, auxi_item = model(samples)
            loss = criterion(outputs, targets)
            ppc_cov_loss = ppc_mean_loss = None
            if args is not None and getattr(args, "use_ppc_loss", False):
                cov_coe, mean_coe = args.ppc_cov_coe, args.ppc_mean_coe
                total_proto_act, cls_attn_rollout, original_fea_len = (
                    auxi_item[2], auxi_item[3], auxi_item[4]
                )
                raw_model = model.module if hasattr(model, "module") else model
                ppc_cov_loss, ppc_mean_loss = raw_model.get_PPC_loss(
                    total_proto_act, cls_attn_rollout, original_fea_len, targets
                )
                ppc_cov_loss = cov_coe * ppc_cov_loss
                ppc_mean_loss = mean_coe * ppc_mean_loss
                if epoch >= 20:
                    loss = loss + ppc_cov_loss + ppc_mean_loss

        loss_value = float(loss.detach().item())
        if not math.isfinite(loss_value):
            logger.error("Non-finite loss %s; stopping training", loss_value)
            sys.exit(1)

        optimizer.zero_grad(set_to_none=True)
        is_second_order = hasattr(optimizer, "is_second_order") and optimizer.is_second_order
        loss_scaler(loss, optimizer, clip_grad=max_norm,
                    parameters=model.parameters(), create_graph=is_second_order)

        # Keep prototype parameters inside the fixed [0,1] prototype-code range.
        if use_qat:
            qat_model.project_prototypes()
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        if model_ema is not None:
            model_ema.update(model)

        metric_logger.update(loss=loss_value)
        metric_logger.update(lr=optimizer.param_groups[0]["lr"])
        tb_writer.add_scalars(
            main_tag="train/loss", tag_scalar_dict={"cls": loss_value},
            global_step=iteration + it,
        )
        if args is not None and getattr(args, "use_global", False) and getattr(args, "use_ppc_loss", False):
            if ppc_cov_loss is not None:
                tb_writer.add_scalars(
                    main_tag="train/ppc_cov_loss", tag_scalar_dict={"ppc_cov_loss": ppc_cov_loss.item()},
                    global_step=iteration + it,
                )
                tb_writer.add_scalars(
                    main_tag="train/ppc_mean_loss", tag_scalar_dict={"ppc_mean_loss": ppc_mean_loss.item()},
                    global_step=iteration + it,
                )
        it += 1

    metric_logger.synchronize_between_processes()
    print("Averaged stats:", metric_logger)
    return {key: meter.global_avg for key, meter in metric_logger.meters.items()}


@torch.no_grad()
def get_img_mask(data_loader, model, device, args):
    logger = logging.getLogger("get mask")
    logger.info("Get mask")
    metric_logger = utils.MetricLogger(delimiter="  ")
    model.eval()
    all_attn_mask = []
    for images, _target in metric_logger.log_every(data_loader, 10, "Get Mask:"):
        images = images.to(device, non_blocking=True)
        with _autocast_context(device):
            cat_mask = model.get_attn_mask(images)
        all_attn_mask.append(cat_mask.cpu())
    if not all_attn_mask:
        raise RuntimeError("Cannot build attention masks from an empty data loader.")
    all_attn_mask = torch.cat(all_attn_mask, dim=0)
    raw_model = model.module if hasattr(model, "module") else model
    raw_model.all_attn_mask = all_attn_mask


@torch.no_grad()
def evaluate(data_loader, model, device, args):
    logger = logging.getLogger("validate")
    logger.info("Start validation")
    criterion = torch.nn.CrossEntropyLoss()
    metric_logger = utils.MetricLogger(delimiter="  ")
    model.eval()
    all_token_attn = []

    for images, target in metric_logger.log_every(data_loader, 10, "Test:"):
        images = images.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True)
        with _autocast_context(device):
            output, auxi_items = model(images)
            loss = criterion(output, target)
        acc1, acc5 = accuracy(output, target, topk=(1, 5))
        batch_size = images.shape[0]
        metric_logger.update(loss=loss.item())
        metric_logger.meters["acc1"].update(acc1.item(), n=batch_size)
        metric_logger.meters["acc5"].update(acc5.item(), n=batch_size)
        if getattr(args, "use_global", False):
            global_acc1 = accuracy(auxi_items[2], target)[0]
            local_acc1 = accuracy(auxi_items[3], target)[0]
            metric_logger.meters["global_acc1"].update(global_acc1.item(), n=batch_size)
            metric_logger.meters["local_acc1"].update(local_acc1.item(), n=batch_size)
        if auxi_items and auxi_items[0] is not None:
            all_token_attn.append(auxi_items[0])

    metric_logger.synchronize_between_processes()
    logger.info(
        "* Acc@1 %.3f Acc@5 %.3f loss %.3f",
        metric_logger.acc1.global_avg, metric_logger.acc5.global_avg, metric_logger.loss.global_avg,
    )
    return {key: meter.global_avg for key, meter in metric_logger.meters.items()}
