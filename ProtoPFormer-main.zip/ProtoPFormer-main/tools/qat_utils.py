"""Utilities shared by ProtoPFormer QAT evaluation and export."""

import math
import torch


def has_valid_range(module):
    value = float(module.running_max.detach().item())
    return math.isfinite(value) and value > 0


def has_missing_observers(model, quant_act_cls):
    raw_model = model.module if hasattr(model, 'module') else model
    return any(isinstance(module, quant_act_cls) and not has_valid_range(module)
               for module in raw_model.modules())


@torch.no_grad()
def calibrate_observers(model, data_loader, device, quant_act_cls, max_batches=32):
    """Collect missing activation ranges in eval mode without changing valid ranges.

    Observers that are never reached remain untouched; export conversion handles
    such unused modules separately. A visited observer that still has no usable
    range is an error.
    """
    raw_model = model.module if hasattr(model, 'module') else model
    observers = [module for module in raw_model.modules() if isinstance(module, quant_act_cls)]
    missing = [module for module in observers if not has_valid_range(module)]
    if not missing:
        return 0

    prior_states = {id(module): (module.observe, module.calibration_mode) for module in observers}
    raw_model.eval()
    for module in observers:
        needs_range = module in missing
        if needs_range:
            # Invalid NaN/Inf ranges cannot seed a max accumulator.
            module.running_max.zero_()
        module.observe = needs_range
        module.calibration_mode = needs_range

    count = 0
    try:
        for images, _targets in data_loader:
            images = images.to(device, non_blocking=True)
            with torch.autocast(device_type=device.type, enabled=(device.type == 'cuda')):
                raw_model(images)
            count += 1
            if count >= max_batches:
                break
    finally:
        for module in observers:
            module.observe, module.calibration_mode = prior_states[id(module)]

    unresolved = [name for name, module in raw_model.named_modules()
                  if isinstance(module, quant_act_cls) and module in missing
                  and module.num_calls > 0 and not has_valid_range(module)]
    if unresolved:
        raise RuntimeError('Observer calibration did not produce valid ranges for: '
                           + ', '.join(unresolved[:12]))
    return count
