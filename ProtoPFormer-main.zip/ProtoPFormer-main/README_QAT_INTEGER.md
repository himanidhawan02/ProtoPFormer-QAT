# ProtoPFormer QAT → hybrid integer CPU deployment

This package updates three files in an existing ProtoPFormer repository:

- `protopformer.py` → repository root
- `main.py` → repository root
- `tools/engine_proto.py` → the existing `tools/` directory

Do not replace the rest of the repository's `tools/` directory. These files still depend on your existing data loaders, Transformer feature wrappers, optimizer/scheduler helpers, preprocessing, and utilities.

## What this implementation does

### During QAT training

- Quantizes selected Transformer `nn.Linear` inputs/weights using fake quantization and an STE.
- Fake-quantizes the 1×1 prototype add-on convolutions.
- Keeps the final classification heads in floating point because they are not QAT-prepared or calibrated.
- Represents the sigmoid-bounded prototype feature maps and prototype vectors on the fixed 8-bit `[0, 1]` code grid.
- Keeps floating-point tensors where autograd needs them and constrains trainable prototype vectors to `[0, 1]` after optimizer steps.
- Tracks activation ranges and freezes their observers for the configured final training epochs.

### After QAT training

`main.py` deep-copies the trained model, converts the selected modules, and saves:

`<output_dir>/checkpoints/int8_model.pth`

Before saving, it compares the QAT reference and converted model on up to 128 validation images, using CPU chunks of 8 by default. It logs maximum absolute logit difference, top-1 agreement, and accuracy for both models on that subset, then separately evaluates QAT and converted-model accuracy across the full validation set in the same small chunks. The artifact records the metrics and a `passed` flag in `export_validation`. Pass status is evidence against these configured checks, not proof of correctness.

The default acceptance criteria are at least 99% top-1 agreement and no more than a 1 percentage-point accuracy drop on both the comparison subset and full validation set. Override these with `--export_min_top1_agreement`, `--export_max_accuracy_drop`, and `--export_max_full_accuracy_drop` to match the experiment's tolerance. A failed check is clearly warned and recorded as `passed: false`; the artifact is still saved for inspection and must not be treated as having passed verification. These are project-specific gates, not universal guarantees.

The exported artifact stores actual `int8` weights for QAT-prepared linear/add-on layers, `uint8` prototype codes, scales and the remaining floating-point parameters needed to reconstruct the model. In the inference path, it performs integer multiply-accumulate operations for:

- QAT-prepared Transformer `Linear` layers
- QAT-prepared 1×1 add-on `Conv2d` layers
- Prototype squared-distance accumulation

These operations currently use PyTorch `int32` matrix-multiplication/sum operations on **CPU**. The custom path stores weights as int8 and prototypes as uint8, but promotes integer codes to int32 for the stock PyTorch integer arithmetic; it is not a vendor-optimized packed-int8 kernel. Distances are converted to float after integer accumulation so ProtoPFormer can apply its `log` similarity function and combine logits.

## Important limitation: this is a hybrid integer model

This is an end-to-end training → export → load → inference workflow, but it is **not an all-operators-integer Transformer**. Operations not converted to integer kernels include Transformer patch-embedding convolutions, LayerNorm, attention score/softmax operations, GELU/sigmoid, residual additions, and the prototype similarity/logit mapping. If `--quantize_backbone False`, ordinary Transformer linears that were not QAT-prepared remain floating point as well.

Consequently, this is a correctness-oriented custom integer inference path, not yet a performance-optimized backend. The int32 temporary tensors and float operations can make it slower than FP32 on some CPUs even though the saved weight tensors are smaller. The export verification checks numerical behavior, not runtime performance or peak memory. Benchmark the original FP32 checkpoint, QAT model, and converted model for latency and memory on the actual target hardware before claiming deployment improvements. Do not describe the complete ProtoPFormer as fully int8. A production-speed implementation would replace these custom operations with backend-supported quantized kernels or validated custom int8/int32 kernels.

## Train with QAT

The training augmentation default is `rand-m9-mmax9-mstd0.5-inc1`. The `mmax9` cap keeps RandAugment's increasing posterize operation within Pillow's valid 1–8 bit range.

Use your **known-working ProtoPFormer training command** and add the following flags. Keep your existing dataset, `--reserve_layers`, `--reserve_token_nums`, prototype shape, optimizer, and architecture arguments unchanged:

```bash
--quantize True \
--quantize_backbone True \
--fmap_bits 8 \
--weight_bits 8 \
--act_bits 8 \
--export_int8 True
```

You may initialise QAT from a trained FP32 checkpoint by adding:

```bash
--qat_init_ckpt /path/to/your_fp32_checkpoint.pth
```

An FP32 checkpoint does not contain activation observer ranges. They are collected during QAT training. If observer ranges are missing during QAT evaluation or export, the script calibrates from a reproducible random subset drawn across the training split (up to 256 images by default), using the same deterministic inference transform as validation: resize, center crop when configured, tensor conversion, and the dataset's inference normalization. It never uses the validation split to set calibration ranges. Export calibrates its CPU copy before creating the QAT comparison reference or converting the model. Calibration observes only missing or invalid ranges, accumulates the maximum across calibration batches, and preserves existing valid ranges. Training-time observer updates continue to use EMA. If a visited observer still has no finite positive range, export stops rather than silently inventing one.

For a distinct FP32 accuracy result in the export report, provide `--fp32_reference_ckpt /path/to/fp32_checkpoint.pth`. The checkpoint must match the requested architecture and dataset configuration. The artifact then records FP32, full-validation QAT, and full-validation integer accuracies separately, plus subset QAT-to-integer agreement and the configured verification status. If no FP32 reference checkpoint is supplied, that metric is recorded as unavailable rather than inferred from QAT.

## Evaluate the exported integer artifact

After training finishes and the artifact is saved, run:

```bash
python main.py \
  --integer_deploy True \
  --resume output_kd/test/checkpoints/int8_model.pth \
  --output_dir output_kd/integer_eval/
```

Replace the checkpoint path with your actual `output_dir`. Dataset and model configuration are read from the deployment artifact; evaluation runs on CPU. The default CPU deployment batch size is 16. Adjust it with `--deploy_batch_size N` if your machine has enough memory.

## Validation included in this package

`smoke_test_qat.py` uses a small synthetic Transformer wrapper to test both local-only and global/local paths. It checks QAT forward/backward, observer helper behavior (missing-only calibration, max-range accumulation, flag restoration, and invalid-range errors), conversion rejection of NaN/Inf ranges, integer inference, strict state-dict export/load round-tripping, and prototype-distance accumulation against a brute-force integer reference. It does **not** run your actual timm feature wrappers, dataset or full training job.

Run the smoke test from this directory with:

```bash
python smoke_test_qat.py
```

Before a long dataset run, copy these files into your repository and run the smoke test plus a short real-dataset QAT run. Compare FP32, fake-quant/QAT evaluation, and exported integer CPU evaluation accuracy; also benchmark file size and latency on the actual deployment hardware.
