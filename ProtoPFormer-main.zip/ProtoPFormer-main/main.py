# Copyright (c) 2015-present, Facebook, Inc.
# All rights reserved.
"""ProtoPFormer training/evaluation entry point with QAT and integer export.

Typical workflow:
  1) Train QAT: python main.py ... --quantize True --quantize_backbone True
  2) The final hybrid integer CPU artifact is written to checkpoints/int8_model.pth.
  3) Evaluate artifact: python main.py --integer_deploy True --resume <artifact> --eval

The exported artifact uses integer MACs for QAT-prepared Linear layers, 1x1
prototype-head Conv2d layers and prototype distances. LayerNorm, attention
softmax, GELU/sigmoid and similarity mapping remain float32, so this is a
hybrid integer deployment path rather than an all-ops-integer Transformer.
"""
import argparse
import copy
import datetime
import logging
import os
import random
import time
from pathlib import Path

import numpy as np
import torch
import torchvision.transforms as transforms
from torch.utils.tensorboard import SummaryWriter
from timm.data import Mixup
from timm.loss import LabelSmoothingCrossEntropy, SoftTargetCrossEntropy
from timm.utils import NativeScaler, get_state_dict, ModelEma

import protopformer
from tools.create_optimizer import create_optimizer
from tools.create_scheduler import create_scheduler
from tools.engine_proto import train_one_epoch, evaluate
from tools.preprocess import mean, std
from tools.datasets import build_dataset, build_dataset_noaug
from tools.qat_utils import calibrate_observers, has_missing_observers
import tools.utils as utils
from tools.utils import str2bool


def get_args_parser():
    parser = argparse.ArgumentParser("ProtoPFormer QAT training and evaluation", add_help=False)
    parser.add_argument('--batch_size', default=256, type=int)
    parser.add_argument('--distillw', type=float, default=0.5)
    parser.add_argument('--enable_smoothing', type=str2bool, default=False)
    parser.add_argument('--enable_mixup', type=str2bool, default=False)
    parser.add_argument('--w_dis_token', type=str2bool, default=False)

    # ProtoPFormer architecture
    parser.add_argument('--base_architecture', type=str, default='deit_tiny_patch16_224')
    parser.add_argument('--img_size', type=int, default=224)
    parser.add_argument('--prototype_shape', nargs='+', type=int, default=[2000, 192, 1, 1])
    parser.add_argument('--prototype_activation_function', type=str, default='log')
    parser.add_argument('--add_on_layers_type', type=str, default='regular')
    parser.add_argument('--baseline_path', type=str, default=None)
    parser.add_argument('--reserve_layers', nargs='+', type=int, default=[])
    parser.add_argument('--reserve_token_nums', nargs='+', type=int, default=[])
    parser.add_argument('--use_global', type=str2bool, default=False)
    parser.add_argument('--use_ppc_loss', type=str2bool, default=False)
    parser.add_argument('--ppc_cov_thresh', type=float, default=1.0)
    parser.add_argument('--ppc_mean_thresh', type=float, default=2.0)
    parser.add_argument('--global_coe', type=float, default=0.5)
    parser.add_argument('--global_proto_per_class', type=int, default=5)
    parser.add_argument('--ppc_cov_coe', type=float, default=0.1)
    parser.add_argument('--ppc_mean_coe', type=float, default=0.5)

    # Quantization-aware training (current deployment converter supports 8-bit only)
    parser.add_argument('--quantize', type=str2bool, default=False,
                        help='enable custom 8-bit QAT for selected Linear/Conv layers and prototype features')
    parser.add_argument('--fmap_bits', type=int, choices=[8], default=8)
    parser.add_argument('--weight_bits', type=int, choices=[8], default=8)
    parser.add_argument('--act_bits', type=int, choices=[8], default=8)
    parser.add_argument('--quantize_backbone', type=str2bool, default=True,
                        help='apply QAT to nn.Linear modules in the Transformer wrapper')
    parser.add_argument('--qat_init_ckpt', type=str, default='',
                        help='FP32 checkpoint used to initialise QAT; activation observers are calibrated separately')
    parser.add_argument('--fp32_reference_ckpt', type=str, default='',
                        help='optional FP32 checkpoint to evaluate and record alongside QAT/integer metrics')
    parser.add_argument('--qat_freeze_epoch', type=int, default=-1,
                        help='freeze activation observers from this epoch; default is the final two epochs')
    parser.add_argument('--export_int8', type=str2bool, default=True,
                        help='export hybrid integer CPU inference artifact after QAT training')
    parser.add_argument('--integer_deploy', type=str2bool, default=False,
                        help='load/run an exported hybrid integer CPU artifact; use with --resume and --eval')
    parser.add_argument('--deploy_batch_size', type=int, default=16,
                        help='batch size for CPU integer deployment evaluation (limits distance-matrix memory)')
    parser.add_argument('--export_verify_batch_size', type=int, default=8,
                        help='small CPU batch size used for export verification')
    parser.add_argument('--export_verify_images', type=int, default=128,
                        help='maximum validation images used for QAT-vs-integer logit/prediction comparison')
    parser.add_argument('--export_min_top1_agreement', type=float, default=99.0,
                        help='minimum QAT/integer top-1 agreement percentage for export verification to pass')
    parser.add_argument('--export_max_accuracy_drop', type=float, default=1.0,
                        help='maximum allowed integer accuracy drop in percentage points on the comparison subset')
    parser.add_argument('--export_max_full_accuracy_drop', type=float, default=1.0,
                        help='maximum allowed integer accuracy drop in percentage points on full validation')

    # Dataset and optimisation
    parser.add_argument('--data_path', type=str, default='./datasets/cub200_cropped/')
    parser.add_argument('--data_set', default='CUB2011U', choices=['CUB2011U', 'Car', 'Dogs'], type=str)
    parser.add_argument('--input_size', default=224, type=int)
    parser.add_argument('--features_lr', type=float, default=1e-4)
    parser.add_argument('--add_on_layers_lr', type=float, default=3e-3)
    parser.add_argument('--prototype_vectors_lr', type=float, default=3e-3)
    parser.add_argument('--joint_lr_step_size', type=int, default=5)
    parser.add_argument('--coefs_crs_ent', type=float, default=1.0)
    parser.add_argument('--coefs_clst', type=float, default=0.8)
    parser.add_argument('--coefs_sep', type=float, default=-0.08)
    parser.add_argument('--coefs_l1', type=float, default=1e-4)
    parser.add_argument('--epochs', type=int, default=40)

    parser.add_argument('--model', default='deit_tiny_patch16_224', type=str)
    parser.add_argument('--save_ep_freq', default=400, type=int)
    parser.add_argument('--drop', type=float, default=0.0)
    parser.add_argument('--drop_path', type=float, default=0.1)
    parser.add_argument('--model_ema', action='store_true')
    parser.add_argument('--no-model-ema', action='store_false', dest='model_ema')
    parser.set_defaults(model_ema=True)
    parser.add_argument('--model-ema-decay', type=float, default=0.99996)
    parser.add_argument('--model-ema-force-cpu', action='store_true', default=False)

    parser.add_argument('--opt', default='adamw', type=str)
    parser.add_argument('--opt-eps', default=1e-8, type=float)
    parser.add_argument('--opt-betas', default=None, type=float, nargs='+')
    parser.add_argument('--clip_grad', type=float, default=None)
    parser.add_argument('--momentum', type=float, default=0.9)
    parser.add_argument('--weight_decay', type=float, default=0.05)
    parser.add_argument('--sched', default='cosine', type=str)
    parser.add_argument('--lr', type=float, default=5e-4)
    parser.add_argument('--lr-noise', type=float, nargs='+', default=None)
    parser.add_argument('--lr-noise-pct', type=float, default=0.67)
    parser.add_argument('--lr-noise-std', type=float, default=1.0)
    parser.add_argument('--warmup-lr', type=float, default=1e-6)
    parser.add_argument('--min-lr', type=float, default=1e-5)
    parser.add_argument('--decay-epochs', type=float, default=30)
    parser.add_argument('--warmup-epochs', type=int, default=5)
    parser.add_argument('--cooldown-epochs', type=int, default=10)
    parser.add_argument('--patience-epochs', type=int, default=10)
    parser.add_argument('--decay-rate', '--dr', type=float, default=0.1)

    # Dataset augmentations used by tools.datasets.build_dataset
    parser.add_argument('--color-jitter', type=float, default=0.4)
    # mmax9 prevents increasing Posterize from producing 0 retained bits,
    # which newer Pillow versions reject (valid range is 1-8).
    parser.add_argument('--aa', type=str, default='rand-m9-mmax9-mstd0.5-inc1')
    parser.add_argument('--smoothing', type=float, default=0.0)
    parser.add_argument('--train-interpolation', type=str, default='bicubic')
    parser.add_argument('--reprob', type=float, default=0.25)
    parser.add_argument('--remode', type=str, default='pixel')
    parser.add_argument('--recount', type=int, default=1)
    parser.add_argument('--resplit', action='store_true', default=False)
    parser.add_argument('--mixup', type=float, default=0.0)
    parser.add_argument('--cutmix', type=float, default=1.0)
    parser.add_argument('--cutmix-minmax', type=float, nargs='+', default=None)
    parser.add_argument('--mixup-prob', type=float, default=1.0)
    parser.add_argument('--mixup-switch-prob', type=float, default=0.5)
    parser.add_argument('--mixup-mode', type=str, default='batch')
    parser.add_argument('--finetune', default='')

    parser.add_argument('--inat-category', default='name',
                        choices=['kingdom', 'phylum', 'class', 'order', 'supercategory', 'family', 'genus', 'name'],
                        type=str)
    parser.add_argument('--output_dir', default='output_kd/test/')
    parser.add_argument('--device', default='cuda')
    parser.add_argument('--seed', default=1028, type=int)
    parser.add_argument('--resume', default='')
    parser.add_argument('--start_epoch', default=0, type=int)
    parser.add_argument('--eval', action='store_true')
    parser.add_argument('--dist-eval', action='store_true', default=False)
    parser.add_argument('--num_workers', default=10, type=int)
    parser.add_argument('--pin-mem', action='store_true')
    parser.add_argument('--no-pin-mem', action='store_false', dest='pin_mem')
    parser.set_defaults(pin_mem=True)
    parser.add_argument('--world_size', default=1, type=int)
    parser.add_argument('--dist_url', default='env://')
    return parser


def get_outlog(args):
    logfile_dir = os.path.join(args.output_dir, 'eval-logs' if args.eval else 'train-logs')
    ckpt_dir = os.path.join(args.output_dir, 'checkpoints')
    tb_dir = os.path.join(args.output_dir, 'tf-logs')
    tb_log_dir = os.path.join(tb_dir, args.model + '_' + args.data_set)
    os.makedirs(logfile_dir, exist_ok=True)
    os.makedirs(ckpt_dir, exist_ok=True)
    os.makedirs(tb_dir, exist_ok=True)
    os.makedirs(tb_log_dir, exist_ok=True)
    tb_writer = SummaryWriter(log_dir=tb_log_dir, flush_secs=1)
    logger = utils.get_logger(level=logging.INFO, mode='w', name=None,
                              logger_fp=os.path.join(logfile_dir, args.model + '_' + args.data_set + '.log'))
    return tb_writer, logger


def set_seed(seed):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def load_model_state(model, state_dict, quantize, logger):
    """Load a regular FP32 or QAT checkpoint, allowing only new observer buffers to be missing."""
    if not quantize:
        model.load_state_dict(state_dict)
        return
    missing, unexpected = model.load_state_dict(state_dict, strict=False)
    bad_missing = [key for key in missing if not key.endswith('running_max')]
    if bad_missing or unexpected:
        raise RuntimeError(f"Checkpoint/model mismatch. missing={bad_missing}; unexpected={unexpected}")
    logger.info('Loaded checkpoint; %d new activation observer buffers were initialised.', len(missing))


def model_config_from_args(args, num_classes):
    keys = [
        'base_architecture', 'img_size', 'prototype_shape', 'reserve_layers', 'reserve_token_nums',
        'use_global', 'use_ppc_loss', 'ppc_cov_thresh', 'ppc_mean_thresh', 'global_coe',
        'global_proto_per_class', 'prototype_activation_function', 'add_on_layers_type',
        'quantize', 'fmap_bits', 'weight_bits', 'act_bits', 'quantize_backbone',
        'data_set', 'data_path', 'input_size',
    ]
    cfg = {key: getattr(args, key) for key in keys}
    cfg['num_classes'] = int(num_classes)
    return cfg


def _load_checkpoint_file(path):
    if not path or path.startswith('https'):
        return None
    # These checkpoints are generated by this training script and contain plain tensors/dicts.
    return torch.load(path, map_location='cpu', weights_only=False)


@torch.no_grad()
def compare_qat_and_integer(qat_model, integer_model, data_loader, max_images=128):
    """Compare a bounded validation subset using one small CPU forward at a time."""
    qat_model.eval()
    integer_model.eval()
    max_abs_diff = 0.0
    matching = 0
    total = 0
    correct = qat_correct = 0
    for images, targets in data_loader:
        for start in range(0, images.shape[0], data_loader.batch_size):
            end = min(start + data_loader.batch_size, images.shape[0], max_images - total)
            if end <= start:
                break
            image_chunk = images[start:end].cpu()
            target_chunk = targets[start:end].cpu()
            qat_logits, _ = qat_model(image_chunk)
            integer_logits, _ = integer_model(image_chunk)
            max_abs_diff = max(max_abs_diff, float((qat_logits - integer_logits).abs().max().item()))
            qat_predictions = qat_logits.argmax(dim=1)
            integer_predictions = integer_logits.argmax(dim=1)
            matching += int((qat_predictions == integer_predictions).sum().item())
            qat_correct += int((qat_predictions == target_chunk).sum().item())
            correct += int((integer_predictions == target_chunk).sum().item())
            total += int(target_chunk.numel())
        if total >= max_images:
            break
    if total == 0:
        raise RuntimeError('Cannot verify integer export: validation loader produced no samples.')
    return {
        'max_abs_logit_diff': max_abs_diff,
        'top1_agreement_pct': 100.0 * matching / total,
        'integer_val_acc1_pct': 100.0 * correct / total,
        'qat_val_acc1_pct': 100.0 * qat_correct / total,
        'num_samples': total,
    }


@torch.no_grad()
def evaluate_accuracy_chunked(model, data_loader, chunk_size=8):
    """Measure full validation accuracy with bounded forwards (batched or unbatched loader)."""
    if chunk_size < 1:
        raise ValueError('chunk_size must be positive.')
    model.eval()
    correct = total = 0
    for images, targets in data_loader:
        if data_loader.batch_size is None:
            images = images.unsqueeze(0)
            targets = targets.reshape(1)
        for start in range(0, images.shape[0], chunk_size):
            end = min(start + chunk_size, images.shape[0])
            logits, _ = model(images[start:end].cpu())
            target_chunk = targets[start:end].cpu().reshape(-1)
            correct += int((logits.argmax(dim=1) == target_chunk).sum().item())
            total += int(target_chunk.numel())
    if total == 0:
        raise RuntimeError('Cannot evaluate integer export: validation loader produced no samples.')
    return 100.0 * correct / total


def build_calibration_loader(args, batch_size):
    """Use a reproducible random subset of training data with deterministic transforms."""
    calibration_dataset, _ = build_dataset_noaug(is_train=True, args=args)
    subset_size = min(len(calibration_dataset), 32 * batch_size)
    generator = torch.Generator().manual_seed(args.seed)
    indices = torch.randperm(len(calibration_dataset), generator=generator)[:subset_size].tolist()
    calibration_subset = torch.utils.data.Subset(calibration_dataset, indices)
    return torch.utils.data.DataLoader(
        calibration_subset,
        sampler=torch.utils.data.SequentialSampler(calibration_subset),
        batch_size=batch_size, num_workers=args.num_workers,
        pin_memory=False, drop_last=False)


def main(args):
    # Load checkpoint early so an integer-deploy run can reconstruct the exact architecture.
    resume_checkpoint = _load_checkpoint_file(args.resume) if args.resume else None
    if args.integer_deploy:
        if resume_checkpoint is None:
            raise ValueError('--integer_deploy True requires a local --resume checkpoint produced by --export_int8 True.')
        config = resume_checkpoint.get('model_config')
        if not isinstance(config, dict):
            raise ValueError('This checkpoint has no model_config; it is not a supported integer-deployment artifact.')
        for key, value in config.items():
            if key in ('num_classes',):
                continue
            setattr(args, key, value)
        args.quantize = True
        args.eval = True
        args.device = 'cpu'
        args.model_ema = False
        if args.deploy_batch_size < 1:
            raise ValueError('--deploy_batch_size must be >= 1.')
        args.batch_size = args.deploy_batch_size

    seed = args.seed + utils.get_rank()
    set_seed(seed)
    if args.enable_smoothing:
        args.smoothing = 0.1
    utils.init_distributed_mode(args)
    if args.integer_deploy and args.distributed:
        raise RuntimeError('Integer deployment evaluation is currently single-process; unset distributed launch variables.')

    tb_writer, logger = get_outlog(args)
    logger.info('Start running with args: %s', args)
    logger.info('Distributed: %s', args.distributed)
    device = torch.device(args.device)

    normalize = transforms.Normalize(mean=mean, std=std)
    dataset_train, args.nb_classes = build_dataset(is_train=True, args=args)
    dataset_val, _ = build_dataset(is_train=False, args=args)
    logger.info('Dataset num_classes: %s', args.nb_classes)
    logger.info('train %s test: %s', len(dataset_train), len(dataset_val))

    if args.integer_deploy and args.nb_classes != int(resume_checkpoint['model_config']['num_classes']):
        raise ValueError(f"Dataset class count {args.nb_classes} does not match deployment artifact class count "
                         f"{resume_checkpoint['model_config']['num_classes']}.")

    if args.distributed:
        num_tasks, global_rank = utils.get_world_size(), utils.get_rank()
        sampler_train = torch.utils.data.DistributedSampler(
            dataset_train, num_replicas=num_tasks, rank=global_rank, shuffle=True)
        if args.dist_eval:
            if len(dataset_val) % num_tasks != 0:
                logger.warning('Distributed eval dataset is not divisible by process count; duplicate entries may affect metrics.')
            sampler_val = torch.utils.data.DistributedSampler(
                dataset_val, num_replicas=num_tasks, rank=global_rank, shuffle=False)
        else:
            sampler_val = torch.utils.data.SequentialSampler(dataset_val)
    else:
        sampler_train = torch.utils.data.RandomSampler(dataset_train)
        sampler_val = torch.utils.data.SequentialSampler(dataset_val)

    data_loader_train = torch.utils.data.DataLoader(
        dataset_train, sampler=sampler_train, batch_size=args.batch_size,
        num_workers=args.num_workers, pin_memory=args.pin_mem, drop_last=True)
    data_loader_val = torch.utils.data.DataLoader(
        dataset_val, sampler=sampler_val,
        batch_size=args.batch_size if args.integer_deploy else int(1.5 * args.batch_size),
        num_workers=args.num_workers, pin_memory=args.pin_mem, drop_last=False)

    mixup_fn = None
    if args.enable_smoothing:
        assert args.smoothing > 0.0
        logger.info('Label smoothing enabled: %s', args.smoothing)
    else:
        assert args.smoothing == 0
        logger.info('Label smoothing disabled')
    if args.enable_mixup:
        mixup_active = args.mixup > 0 or args.cutmix > 0 or args.cutmix_minmax is not None
        if mixup_active:
            mixup_fn = Mixup(mixup_alpha=args.mixup, cutmix_alpha=args.cutmix,
                             cutmix_minmax=args.cutmix_minmax, prob=args.mixup_prob,
                             switch_prob=args.mixup_switch_prob, mode=args.mixup_mode,
                             label_smoothing=args.smoothing, num_classes=args.nb_classes)
    else:
        assert args.mixup == 0.0
        logger.info('Mixup is not enabled')

    model = protopformer.construct_PPNet(
        base_architecture=args.base_architecture,
        pretrained=(not args.integer_deploy), img_size=args.img_size,
        prototype_shape=args.prototype_shape, num_classes=args.nb_classes,
        reserve_layers=args.reserve_layers, reserve_token_nums=args.reserve_token_nums,
        use_global=args.use_global, use_ppc_loss=args.use_ppc_loss,
        ppc_cov_thresh=args.ppc_cov_thresh, ppc_mean_thresh=args.ppc_mean_thresh,
        global_coe=args.global_coe, global_proto_per_class=args.global_proto_per_class,
        prototype_activation_function=args.prototype_activation_function,
        add_on_layers_type=args.add_on_layers_type, quantize=args.quantize,
        fmap_bits=args.fmap_bits, weight_bits=args.weight_bits, act_bits=args.act_bits,
        quantize_backbone=args.quantize_backbone,
    )

    if args.integer_deploy:
        model.cpu()
        model.convert_to_integer_deployment(require_calibrated=False)
        state_dict = resume_checkpoint.get('model')
        if state_dict is None:
            raise ValueError('Deployment checkpoint is missing the model state dictionary.')
        model.load_state_dict(state_dict, strict=True)
        model.eval()
        deploy_device = torch.device('cpu')
        stats = evaluate(data_loader_val, model, deploy_device, args)
        logger.info('Hybrid integer CPU deployment accuracy on %d test images: %.3f%%',
                    len(dataset_val), stats['acc1'])
        tb_writer.close()
        return

    if args.quantize:
        logger.info('QAT enabled: 8-bit feature/prototype codes, 8-bit weights/activations; backbone Linear quantization=%s',
                    args.quantize_backbone)

    if args.qat_init_ckpt:
        if not args.quantize:
            raise ValueError('--qat_init_ckpt is only meaningful with --quantize True.')
        init_ckpt = _load_checkpoint_file(args.qat_init_ckpt)
        if init_ckpt is None:
            init_ckpt = torch.hub.load_state_dict_from_url(args.qat_init_ckpt, map_location='cpu', check_hash=True)
        init_state = init_ckpt.get('model', init_ckpt)
        load_model_state(model, init_state, True, logger)
        logger.info('Initialised QAT from %s', args.qat_init_ckpt)

    model.to(device)
    model_ema = None
    if args.model_ema:
        model_ema = ModelEma(model, decay=args.model_ema_decay,
                            device='cpu' if args.model_ema_force_cpu else '', resume='')

    model_without_ddp = model
    if args.distributed:
        model = torch.nn.parallel.DistributedDataParallel(
            model, device_ids=[args.gpu] if device.type == 'cuda' else None,
            find_unused_parameters=True)
        model_without_ddp = model.module
    n_parameters = sum(p.numel() for p in model.parameters() if p.requires_grad)
    logger.info('Number of trainable parameters: %d', n_parameters)

    # Optimiser/scheduler are only constructed for train/eval of a normal FP32/QAT model.
    joint_optimizer_lrs = {
        'features': args.features_lr,
        'add_on_layers': args.add_on_layers_lr,
        'prototype_vectors': args.prototype_vectors_lr,
    }
    optimizer = create_optimizer(args, model_without_ddp, joint_optimizer_lrs=joint_optimizer_lrs)
    loss_scaler = NativeScaler()
    lr_scheduler, _ = create_scheduler(args, optimizer)

    if args.mixup > 0.:
        criterion = SoftTargetCrossEntropy()
    elif args.smoothing:
        criterion = LabelSmoothingCrossEntropy(smoothing=args.smoothing)
    else:
        criterion = torch.nn.CrossEntropyLoss()

    if args.resume:
        if args.resume.startswith('https'):
            checkpoint = torch.hub.load_state_dict_from_url(args.resume, map_location='cpu', check_hash=True)
        else:
            checkpoint = resume_checkpoint
        if checkpoint is None:
            raise RuntimeError('Could not load resume checkpoint.')
        load_model_state(model_without_ddp, checkpoint['model'], args.quantize, logger)
        if not args.eval and 'optimizer' in checkpoint and 'lr_scheduler' in checkpoint and 'epoch' in checkpoint:
            optimizer.load_state_dict(checkpoint['optimizer'])
            lr_scheduler.load_state_dict(checkpoint['lr_scheduler'])
            args.start_epoch = checkpoint['epoch'] + 1
            if args.model_ema and 'model_ema' in checkpoint:
                utils._load_checkpoint_for_ema(model_ema, checkpoint['model_ema'])
            if 'scaler' in checkpoint:
                loss_scaler.load_state_dict(checkpoint['scaler'])

    if args.eval:
        if args.quantize:
            batches = 0
            if has_missing_observers(model, protopformer.QuantAct):
                calibration_loader = build_calibration_loader(args, args.export_verify_batch_size)
                batches = calibrate_observers(
                    model, calibration_loader, device, protopformer.QuantAct)
            if batches:
                logger.info('Calibrated missing QAT activation observer ranges with %d batches.', batches)
        test_stats = evaluate(data_loader_val, model, device, args)
        logger.info('Accuracy of the network on %d test images: %.3f%%', len(dataset_val), test_stats['acc1'])
        tb_writer.close()
        return

    # A short QAT run still needs at least one epoch with live observers.
    qat_freeze_epoch = args.qat_freeze_epoch if args.qat_freeze_epoch >= 0 else max(args.epochs - 2, 1)
    logger.info('Start training for %d epochs', args.epochs)
    start_time = time.time()
    max_accuracy = 0.0
    best_model_state = None
    iteration = 0
    output_dir = Path(args.output_dir)
    for epoch in range(args.start_epoch, args.epochs):
        if args.distributed:
            data_loader_train.sampler.set_epoch(epoch)
        if args.quantize and epoch >= qat_freeze_epoch:
            if has_missing_observers(model_without_ddp, protopformer.QuantAct):
                logger.info('Keeping activation observers enabled at epoch %d because ranges are still missing.', epoch)
            else:
                if epoch == qat_freeze_epoch:
                    logger.info('Freezing activation observers from epoch %d', epoch)
                model_without_ddp.set_quant_observer(False)

        train_stats = train_one_epoch(
            model=model, criterion=criterion, data_loader=data_loader_train,
            optimizer=optimizer, device=device, epoch=epoch, loss_scaler=loss_scaler,
            max_norm=args.clip_grad, model_ema=model_ema, mixup_fn=mixup_fn,
            args=args, tb_writer=tb_writer, iteration=iteration,
        )
        iteration += len(data_loader_train)
        logger.info('Averaged train stats: %s', train_stats)
        tb_writer.add_scalar('epoch/train_loss', train_stats['loss'], epoch)
        lr_scheduler.step(epoch)

        if args.output_dir and (epoch + 1) % args.save_ep_freq == 0:
            save_path = output_dir / 'checkpoints' / f'checkpoint-{epoch}.pth'
            utils.save_on_master({
                'model': model_without_ddp.state_dict(), 'optimizer': optimizer.state_dict(),
                'lr_scheduler': lr_scheduler.state_dict(), 'epoch': epoch,
                'model_ema': get_state_dict(model_ema), 'scaler': loss_scaler.state_dict(),
                'args': args,
            }, save_path)

        if args.quantize and has_missing_observers(model_without_ddp, protopformer.QuantAct):
            calibration_loader = build_calibration_loader(args, args.export_verify_batch_size)
            calibrated_batches = calibrate_observers(
                model_without_ddp, calibration_loader, device, protopformer.QuantAct)
            if calibrated_batches:
                logger.info('Calibrated remaining observer ranges from %d training-split batches before validation.',
                            calibrated_batches)
        test_stats = evaluate(data_loader_val, model, device, args)
        logger.info('Validation stats: %s', test_stats)
        tb_writer.add_scalar('epoch/val_acc1', test_stats['acc1'], epoch)
        tb_writer.add_scalar('epoch/val_loss', test_stats['loss'], epoch)
        tb_writer.add_scalar('epoch/val_acc5', test_stats['acc5'], epoch)
        if args.use_global:
            tb_writer.add_scalar('epoch/global_acc1', test_stats['global_acc1'], epoch)
            tb_writer.add_scalar('epoch/local_acc1', test_stats['local_acc1'], epoch)

        if max_accuracy < test_stats['acc1']:
            best_model_state = copy.deepcopy(model_without_ddp.state_dict())
            best_path = output_dir / 'checkpoints' / 'epoch-best.pth'
            utils.save_on_master({
                'model': model_without_ddp.state_dict(), 'optimizer': optimizer.state_dict(),
                'lr_scheduler': lr_scheduler.state_dict(), 'epoch': epoch,
                'model_ema': get_state_dict(model_ema), 'scaler': loss_scaler.state_dict(),
                'args': args,
            }, best_path)
        max_accuracy = max(max_accuracy, test_stats['acc1'])
        logger.info('Max validation accuracy so far: %.3f%%', max_accuracy)

    total_time = str(datetime.timedelta(seconds=int(time.time() - start_time)))
    logger.info('Training time %s', total_time)

    if args.quantize and args.export_int8 and utils.get_rank() == 0:
        logger.info('Converting a copy of the trained model into the hybrid integer CPU inference path...')
        deploy_model = copy.deepcopy(model_without_ddp)
        if best_model_state is not None:
            deploy_model.load_state_dict(best_model_state, strict=True)
            logger.info('Exporting the best-validation-accuracy QAT checkpoint (%.3f%%).', max_accuracy)
        deploy_model = deploy_model.cpu().eval()
        if args.export_verify_batch_size < 1 or args.export_verify_images < 1:
            raise ValueError('Export verification batch size and image limit must be positive.')
        if (not 0 <= args.export_min_top1_agreement <= 100
                or args.export_max_accuracy_drop < 0
                or args.export_max_full_accuracy_drop < 0):
            raise ValueError('Export thresholds must use agreement in [0, 100] and non-negative accuracy drops.')
        export_loader = torch.utils.data.DataLoader(
            dataset_val, sampler=torch.utils.data.SequentialSampler(dataset_val),
            batch_size=args.export_verify_batch_size, num_workers=args.num_workers,
            pin_memory=False, drop_last=False)
        calibration_batches = 0
        if has_missing_observers(deploy_model, protopformer.QuantAct):
            calibration_loader = build_calibration_loader(
                args, args.export_verify_batch_size)
            calibration_batches = calibrate_observers(
                deploy_model, calibration_loader, torch.device('cpu'), protopformer.QuantAct)
        if calibration_batches:
            logger.info('Calibrated missing export-copy observer ranges from %d training-split batches.',
                        calibration_batches)
        qat_reference = copy.deepcopy(deploy_model).eval()
        deploy_model.convert_to_integer_deployment(require_calibrated=True)
        export_check = compare_qat_and_integer(
            qat_reference, deploy_model, export_loader, max_images=args.export_verify_images)
        accuracy_drop = export_check['qat_val_acc1_pct'] - export_check['integer_val_acc1_pct']
        failures = []
        if export_check['top1_agreement_pct'] < args.export_min_top1_agreement:
            failures.append('top1_agreement_below_threshold')
        if accuracy_drop > args.export_max_accuracy_drop:
            failures.append('accuracy_drop_above_threshold')
        export_check.update({
            'max_images': args.export_verify_images,
            'min_top1_agreement_pct': args.export_min_top1_agreement,
            'max_accuracy_drop_percentage_points': args.export_max_accuracy_drop,
            'accuracy_drop_percentage_points': accuracy_drop,
        })
        qat_full_accuracy = evaluate_accuracy_chunked(qat_reference, export_loader,
                                                      chunk_size=args.export_verify_batch_size)
        integer_full_accuracy = evaluate_accuracy_chunked(deploy_model, export_loader,
                                                          chunk_size=args.export_verify_batch_size)
        export_check['qat_full_validation_acc1_pct'] = qat_full_accuracy
        export_check['integer_full_validation_acc1_pct'] = integer_full_accuracy
        full_accuracy_drop = qat_full_accuracy - integer_full_accuracy
        if full_accuracy_drop > args.export_max_full_accuracy_drop:
            failures.append('full_validation_accuracy_drop_above_threshold')
        export_check['full_accuracy_drop_percentage_points'] = full_accuracy_drop
        export_check['max_full_accuracy_drop_percentage_points'] = args.export_max_full_accuracy_drop
        fp32_full_accuracy = None
        if args.fp32_reference_ckpt:
            fp32_checkpoint = _load_checkpoint_file(args.fp32_reference_ckpt)
            if fp32_checkpoint is None:
                fp32_checkpoint = torch.hub.load_state_dict_from_url(
                    args.fp32_reference_ckpt, map_location='cpu', check_hash=True)
            fp32_state = fp32_checkpoint.get('model', fp32_checkpoint)
            fp32_model = protopformer.construct_PPNet(
                base_architecture=args.base_architecture, pretrained=False, img_size=args.img_size,
                prototype_shape=args.prototype_shape, num_classes=args.nb_classes,
                reserve_layers=args.reserve_layers, reserve_token_nums=args.reserve_token_nums,
                use_global=args.use_global, use_ppc_loss=args.use_ppc_loss,
                ppc_cov_thresh=args.ppc_cov_thresh, ppc_mean_thresh=args.ppc_mean_thresh,
                global_coe=args.global_coe, global_proto_per_class=args.global_proto_per_class,
                prototype_activation_function=args.prototype_activation_function,
                add_on_layers_type=args.add_on_layers_type, quantize=False)
            fp32_model.load_state_dict(fp32_state, strict=True)
            fp32_model.cpu().eval()
            fp32_full_accuracy = evaluate_accuracy_chunked(
                fp32_model, export_loader, chunk_size=args.export_verify_batch_size)
            del fp32_model
        export_check['fp32_full_validation_acc1_pct'] = fp32_full_accuracy
        export_check['passed'] = not failures
        export_check['failures'] = failures
        logger.info('QAT vs integer export check on %d validation samples: max_abs_logit_diff=%.6g, '
                    'top1_agreement=%.3f%%, subset_accuracy QAT=%.3f%% integer=%.3f%%, '
                    'full_val_acc1 FP32=%s QAT=%.3f%% integer=%.3f%%, status=%s%s',
                    export_check['num_samples'], export_check['max_abs_logit_diff'],
                    export_check['top1_agreement_pct'], export_check['qat_val_acc1_pct'],
                    export_check['integer_val_acc1_pct'],
                    'not supplied' if fp32_full_accuracy is None else f'{fp32_full_accuracy:.3f}%',
                    qat_full_accuracy, integer_full_accuracy,
                    'PASS' if export_check['passed'] else 'FAIL',
                    '' if export_check['passed'] else ': ' + ', '.join(failures))
        if not export_check['passed']:
            logger.warning('Export verification failed configured acceptance criteria; artifact will be saved with passed=false for inspection.')
        deploy_path = output_dir / 'checkpoints' / 'int8_model.pth'
        deploy_payload = {
            'format': 'protopformer_hybrid_integer_cpu_v1',
            'model': deploy_model.state_dict(),
            'model_config': model_config_from_args(args, args.nb_classes),
            'execution_contract': {
                'integer_mac_layers': 'QAT-prepared Linear layers, QAT 1x1 Conv2d add-on layers, prototype L2 distance',
                'floating_point_layers': 'Transformer LayerNorm/softmax/GELU, residual and activation ops, prototype similarity/logits mapping',
                'device': 'cpu',
                'all_ops_integer': False,
            },
            'export_validation': export_check,
        }
        torch.save(deploy_payload, deploy_path)
        deploy_tensor_bytes = sum(t.numel() * t.element_size() for t in deploy_model.state_dict().values())
        source_tensor_bytes = sum(t.numel() * t.element_size() for t in model_without_ddp.state_dict().values())
        logger.info('Saved hybrid integer deployment artifact: %s (state tensors %.2f MB; QAT state tensor baseline %.2f MB; ratio %.2fx)',
                    deploy_path, deploy_tensor_bytes / 1e6, source_tensor_bytes / 1e6,
                    source_tensor_bytes / max(deploy_tensor_bytes, 1))

    tb_writer.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser('ProtoPFormer QAT script', parents=[get_args_parser()])
    args = parser.parse_args()
    if args.integer_deploy:
        args.device = 'cpu'
        args.eval = True
        args.model_ema = False
    if args.output_dir:
        Path(args.output_dir).mkdir(parents=True, exist_ok=True)
        Path(args.output_dir, 'checkpoints').mkdir(parents=True, exist_ok=True)
    main(args)
